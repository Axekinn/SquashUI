"""Sidebar groups and per-page titles."""
from __future__ import annotations

from ..organize import ORG_TOOLS


NAV_GROUPS = (
    ("CONVERSION", (("chd", "CHD  (CD / DVD)"), ("rvz", "RVZ  (GameCube / Wii)"), ("cso", "CSO  (PSP)"),
                    ("zar", "ZAR  (PS4 folders)"), ("ps3", "PS3  (decrypt / extract)"), ("xbox", "Xbox  (ISO to XISO)"))),
    ("PKG", (("pkg", "PS4  (PKG_Extractor / orbis)"), ("pkg5", "PS5  (pkg-to-anyps5)"))),
    ("ORGANISATION", tuple((t.key, t.nav) for t in ORG_TOOLS.values())),
    ("DOWNLOAD", (("dl", "Files & torrents"), ("act_logins", "Logins..."), ("act_torrent", "Torrent privacy..."))),
)


PAGE_INFO = {
    "chd": ("CHD conversion", "CD and DVD systems (PS1, PS2, Saturn, Dreamcast, CD-i ...) with chdman."),
    "rvz": ("RVZ conversion", "GameCube and Wii discs with DolphinTool."),
    "cso": ("CSO conversion", "PSP discs with maxcso."),
    "pkg": ("PS4 PKG extraction", "Extract PS4 .pkg files into loose game folders with ShadPS4Plus PKG_Extractor "
                                  "or orbis-pkg-util (ready for shadPS4), optionally packing each one into a .zar."),
    "pkg5": ("PS5 PKG extraction", "Extract PS5 debug .pkg files with pkg-to-anyps5, then either relink them "
                                   "for AnyPS5 or pack the game files with eboot.bin at the root into a .zar "
                                   "for KytyPS5."),
    "zar": ("ZAR packing", "Pack loose PS4 game, update and DLC folders into single .zar files with ZArchive. "
                           "shadPS4 0.17+ reads a .zar directly, so a 20,000-file game becomes one compressed file."),
    "ps3": ("PS3 disc decrypting", "Decrypt Redump PS3 ISOs with PS3Dec (from PS3QDD) and its .dkey files, then keep the "
                                   "ISO, unpack it into a loose folder, or both. Results are named from PARAM.SFO: "
                                   "Game Name - Title ID."),
    "xbox": ("Xbox XISO conversion", "Repack Xbox and Xbox 360 ISOs as trimmed .xiso files with xdvdfs (no video partition, "
                                     "no padding), checked against the source by a content checksum."),
    "dl": ("Downloads & torrents", "Fetch archive.org items, file listings, 1fichier links, magnet links and .torrent "
           "files, with resume and verification."),
    **{t.key: (t.title, t.blurb) for t in ORG_TOOLS.values()},
}
