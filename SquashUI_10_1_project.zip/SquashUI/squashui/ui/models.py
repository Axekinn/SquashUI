"""Table model and filter proxy for the download list."""
from __future__ import annotations

from typing import TYPE_CHECKING

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt

from ..models import fmt_size

if TYPE_CHECKING:
    from ..downloads import RemoteFile


# --- Download list model --------------------------------------------------------------------------
class DlModel(QAbstractTableModel):
    """The Download tab's file list: name, size, status and speed per file, plus which are ticked."""

    HEAD = ("", "File", "Size", "Status", "Speed")

    def __init__(self) -> None:
        super().__init__()
        self.files: list[RemoteFile] = []
        self.checked: set[int] = set()
        self.status: list[str] = []
        self.speed: list[str] = []

    def set_files(self, files: list[RemoteFile]) -> None:
        self.beginResetModel()
        self.files = files
        self.status = [""] * len(files)
        self.speed = [""] * len(files)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.files)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.HEAD)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self.HEAD[section]
        return None

    def flags(self, index) -> Qt.ItemFlag:
        return Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or index.row() >= len(self.files):
            return None
        i, col = index.row(), index.column()
        rf = self.files[i]
        if role == Qt.ItemDataRole.CheckStateRole and col == 0:
            return 2 if i in self.checked else 0
        if role == Qt.ItemDataRole.DisplayRole:
            if col == 1:
                return rf.name
            if col == 2:
                return fmt_size(rf.size) if rf.size is not None else "..."
            if col == 3:
                return self.status[i]
            if col == 4:
                return self.speed[i]
        elif role == Qt.ItemDataRole.UserRole:  # what clicking a header sorts by
            if col == 0:
                return int(i in self.checked)
            if col == 1:
                return rf.name.lower()
            if col == 2:
                return -1 if rf.size is None else rf.size
            return self.status[i] if col == 3 else self.speed[i]
        elif role == Qt.ItemDataRole.ToolTipRole and col == 1:
            return rf.name
        return None

    def _touch(self, i: int, col: int) -> None:
        if 0 <= i < len(self.files):
            ix = self.index(i, col)
            self.dataChanged.emit(ix, ix)

    def set_status(self, i: int, text: str) -> None:
        if 0 <= i < len(self.files):
            self.status[i] = text
            self._touch(i, 3)

    def set_speed(self, i: int, text: str) -> None:
        if 0 <= i < len(self.files):
            self.speed[i] = text
            self._touch(i, 4)

    def size_changed(self, i: int) -> None:
        self._touch(i, 2)

    def toggle(self, rows: list[int]) -> None:
        for i in rows:
            self.checked ^= {i}
            self._touch(i, 0)

    def set_checked(self, i: int, on: bool) -> None:
        if (i in self.checked) != on:
            self.toggle([i])

    def refresh_checks(self) -> None:
        if self.files:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.files) - 1, 0))


class DlProxy(QSortFilterProxyModel):
    """Hides rows the filter / "archive.org extras" setting rules out, and sorts by column."""

    def __init__(self) -> None:
        super().__init__()
        self.visible: set[int] | None = None
        self.setSortRole(Qt.ItemDataRole.UserRole)

    def filterAcceptsRow(self, source_row: int, source_parent) -> bool:
        return self.visible is None or source_row in self.visible

    def set_visible(self, rows: set[int]) -> None:
        self.visible = rows
        self.invalidateFilter()
