"""Download page: link list, torrent/login dialogs, the download run and its saved session."""
from __future__ import annotations

import contextlib
import json
import os
import threading
import time
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFontDatabase
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QFileDialog,
    QHBoxLayout, QHeaderView, QLineEdit, QMessageBox,
    QPlainTextEdit, QPushButton, QVBoxLayout, QWidget,
)

from ..downloads import DL_MAX_PARALLEL, DownloadRunner, logins_missing, RemoteFile, SESSION_FILE
from ..links import probe_sizes, resolve_links
from ..models import fmt_duration, fmt_size
from ..torbox import torbox_key
from ..torrent_runners import TorBoxRunner, TorrentRunner
from ..torrents import ENGINE, import_libtorrent, is_torrent_token, load_torrent_settings, NEEDS_LIBTORRENT
from .dialogs import LoginsDialog, TorrentDialog
from .state import LABEL_W
from .widgets import Card, Expander, hint, PathRow, ToggleTable


class DownloadMixin:
    """Download page: link list, torrent/login dialogs, the download run and its saved session.

    Methods only; the state lives on SquashUIWindow, which mixes this in."""

    @property
    def dl_files(self) -> list[RemoteFile]:
        return self.dl_model.files

    @property
    def dl_checked(self) -> set[int]:
        return self.dl_model.checked

    @dl_checked.setter
    def dl_checked(self, value: set[int]) -> None:
        self.dl_model.checked = value

    def _build_dl_page(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)

        links = Expander("Links", expanded=True)
        links.add(hint("Paste one or more archive.org item links (or a link to a plain file listing), one per line. "
                       "Magnet links and .torrent files work too - drop them anywhere on this page."))
        self.dl_url_text = QPlainTextEdit()
        self.dl_url_text.setFixedHeight(72)
        self.dl_url_text.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.dl_url_text.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
        self.dl_url_text.setPlaceholderText("https://archive.org/details/...")
        self.dl_url_text.setAcceptDrops(False)  # a drop falls through to the window, which understands torrents
        links.add(self.dl_url_text)
        row = QHBoxLayout()
        self.dl_fetch_btn = QPushButton("Fetch file list")
        self.dl_fetch_btn.clicked.connect(self._dl_fetch)
        self.dl_status = hint("")
        row.addWidget(self.dl_fetch_btn)
        row.addSpacing(6)
        row.addWidget(self.dl_status, 1)
        links.add(row)
        lay.addWidget(links)

        self.dl_dest = PathRow("Save to", label_width=LABEL_W)
        self.dl_dest.edit.setAcceptDrops(False)
        self.dl_dest.edit.textChanged.connect(lambda *_: self._dl_save_soon())
        dest = Expander("Save location", expanded=True)
        dest.add(self.dl_dest)
        lay.addWidget(dest)

        files = Card("Files  (click a row to tick or untick it)")
        bar = QHBoxLayout()
        bar.setSpacing(8)
        self.dl_filter = QLineEdit()
        self.dl_filter.setPlaceholderText("Filter files")
        self.dl_filter.setClearButtonEnabled(True)
        self.dl_filter.setAcceptDrops(False)
        self.dl_filter.setMaximumWidth(260)
        self.dl_filter.textChanged.connect(lambda *_: self._dl_filter_timer.start())
        select = QPushButton("Select shown")
        select.clicked.connect(lambda: self._dl_select(True))
        clear = QPushButton("Clear shown")
        clear.clicked.connect(lambda: self._dl_select(False))
        self.dl_extras = QCheckBox("Show archive.org extras")
        self.dl_extras.toggled.connect(lambda *_: (self._dl_apply_filter(), self._dl_save_soon()))
        for w in (self.dl_filter, select, clear, self.dl_extras):
            bar.addWidget(w)
        bar.addStretch(1)
        files.add(bar)

        table = self.dl_table = ToggleTable()
        table.setModel(self.dl_proxy)
        table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setShowGrid(False)
        table.setWordWrap(False)
        table.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        table.setMinimumHeight(190)
        table.verticalHeader().setVisible(False)
        table.verticalHeader().setDefaultSectionSize(30)
        table.setSortingEnabled(True)
        table.sortByColumn(-1, Qt.SortOrder.AscendingOrder)  # until a header is clicked the list keeps its own order
        hdr = table.horizontalHeader()
        hdr.setStretchLastSection(False)
        hdr.setHighlightSections(False)
        for col, mode in ((0, QHeaderView.ResizeMode.Fixed), (1, QHeaderView.ResizeMode.Stretch),
                          (2, QHeaderView.ResizeMode.Interactive), (3, QHeaderView.ResizeMode.Interactive),
                          (4, QHeaderView.ResizeMode.Interactive)):
            hdr.setSectionResizeMode(col, mode)
        for col, width in ((0, 40), (2, 92), (3, 230), (4, 96)):
            table.setColumnWidth(col, width)
        hdr.sectionResized.connect(lambda *_: self._dl_save_soon())
        table.clicked.connect(self._dl_clicked)
        table.rowsToggled.connect(self._dl_rows_toggled)
        files.add(table)
        self.dl_sel_label = hint("Paste a link above and press Fetch file list.")
        files.add(self.dl_sel_label)
        lay.addWidget(files)

        return page

    def _logins_dialog(self, needed: list[str] | None = None) -> bool:
        """Modal sign-in window. Returns False only when the person cancels."""
        dlg = LoginsDialog(self, needed, self.dl_remember)
        dlg.exec()
        if dlg.ok:
            self.dl_remember = dlg.remember_value
        return dlg.ok

    def _torrent_dialog(self) -> bool:
        dlg = TorrentDialog(self)
        dlg.exec()
        return dlg.ok

    def _torrent_ready(self, network: bool) -> bool:
        """libtorrent installed and, for anything that touches the swarm, the privacy settings chosen."""
        if import_libtorrent() is None:
            self._info("Torrent support", NEEDS_LIBTORRENT)
            return False
        cfg = load_torrent_settings()
        if network and cfg["require_vpn"] and not cfg["adapter"]:
            return self._torrent_dialog()
        return True

    def _dl_login_check(self, urls: list[str], required_only: bool = False) -> bool:
        """Ask for logins the job involves but doesn't have yet. False = the person cancelled."""
        if missing := logins_missing(urls, required_only):
            return self._logins_dialog(missing)
        return True

    def _dl_add_links(self, links: list[str]) -> None:
        have = set(self.dl_url_text.toPlainText().split())
        if fresh := [link for link in links if link not in have]:
            current = self.dl_url_text.toPlainText().strip()
            self.dl_url_text.setPlainText((current + "\n" if current else "") + "\n".join(fresh))
        if not isinstance(self.runner, DownloadRunner):
            self._dl_fetch()

    def _dl_open_torrents(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Open .torrent file(s)", "", "Torrent files (*.torrent)")
        if paths:
            self._dl_add_links([Path(p).resolve().as_uri() for p in paths])

    def dragEnterEvent(self, event) -> None:
        mime = event.mimeData()
        if self.current_page == "dl" and (mime.hasUrls() or mime.hasText()):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dropEvent(self, event) -> None:
        mime, links = event.mimeData(), []
        for url in mime.urls():
            if url.isLocalFile():
                local = url.toLocalFile()
                if local.lower().endswith(".torrent") and Path(local).is_file():
                    links.append(Path(local).resolve().as_uri())
            elif url.scheme().lower() == "magnet" and url.toString() not in links:
                links.append(url.toString())
        if mime.hasText():
            links += [piece for piece in mime.text().split() if piece.lower().startswith("magnet:") and piece not in links]
        if links:
            self._dl_add_links(links)
        else:
            self.dl_status.setText("Drop .torrent files or magnet links here.")
        event.acceptProposedAction()

    def _dl_fetch(self) -> None:
        text = self.dl_url_text.toPlainText().strip()
        if not text:
            self.dl_status.setText("Paste a link first.")
            return
        tokens = text.split()
        if not self._dl_login_check([t for t in tokens if not is_torrent_token(t)], required_only=True):
            return
        # With a TorBox key a cached torrent is listed from TorBox, so the swarm (and the VPN it needs) is only
        # involved when it isn't cached; list_torrent reports a missing VPN / libtorrent itself in that case.
        if any(is_torrent_token(t) for t in tokens) and not torbox_key() and not self._torrent_ready(
                network=any(t.lower().strip("\"'").startswith("magnet:") for t in tokens)):
            return
        self._dl_token += 1
        self.dl_fetch_btn.setEnabled(False)
        self.dl_status.setText("Fetching file list...")
        threading.Thread(target=self._dl_resolve, args=(self._dl_token, text), daemon=True).start()

    def _dl_resolve(self, token: int, text: str) -> None:  # worker thread: no Qt in here
        ENGINE.note = lambda msg: self.ui_q.put(("dl_note", token, msg))
        try:
            files, errors = resolve_links(text)
        except Exception as exc:
            files, errors = [], [f"Unexpected error: {exc}"]
        self.ui_q.put(("dl_files", token, files, errors))
        if files:  # listings without sizes get them filled in as the answers arrive
            probe_sizes(files, lambda i, n: self.ui_q.put(("dl_size", token, i, n)))

    def _dl_populate(self, files: list[RemoteFile], errors: list[str]) -> None:
        if not isinstance(self.runner, DownloadRunner):
            self.dl_fetch_btn.setEnabled(True)
        self.dl_model.set_files(files)
        pre = {i for i, rf in enumerate(files) if rf.preselect}
        self.dl_checked = pre or {i for i, rf in enumerate(files) if not rf.extra}
        note = f"{len(files)} file(s) found"
        if extras := sum(rf.extra for rf in files):
            note += f" ({extras} archive.org extras hidden)"
        if errors:
            note = errors[0] if not files else note + f" - {len(errors)} link(s) had problems (see the log)"
        self.dl_status.setText(note)
        self._dl_apply_filter()

    def _dl_visible(self) -> list[int]:
        terms = self.dl_filter.text().lower().split()
        extras = self.dl_extras.isChecked()
        return [i for i, rf in enumerate(self.dl_files)
                if (extras or not rf.extra) and all(t in rf.name.lower() for t in terms)]

    def _dl_apply_filter(self) -> None:
        self._dl_filter_timer.stop()
        if not self.dl_extras.isChecked():  # hidden files can't stay ticked
            self.dl_checked = self.dl_checked - {i for i, rf in enumerate(self.dl_files) if rf.extra}
        self.dl_proxy.set_visible(set(self._dl_visible()))
        self.dl_model.refresh_checks()
        self._dl_update_sel()

    def _dl_update_sel(self) -> None:
        if not self.dl_files:
            return
        picks = [self.dl_files[i] for i in self.dl_checked if i < len(self.dl_files)]
        self._dl_save_soon()
        total = sum(rf.size or 0 for rf in picks)
        more = "+" if any(rf.size is None for rf in picks) else ""
        self.dl_sel_label.setText(f"{len(picks)} of {len(self.dl_files)} file(s) selected ({fmt_size(total)}{more})")

    def _dl_toggle(self, indices: list[int]) -> None:
        self.dl_model.toggle(indices)
        self._dl_update_sel()

    def _dl_select(self, on: bool) -> None:
        if isinstance(self.runner, DownloadRunner):
            return
        self._dl_toggle([i for i in self._dl_visible() if (i in self.dl_checked) != on])

    def _dl_clicked(self, index) -> None:
        if isinstance(self.runner, DownloadRunner) or not index.isValid():
            return
        if QApplication.keyboardModifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier):
            return  # extending the selection, not ticking
        self._dl_toggle([self.dl_proxy.mapToSource(index).row()])

    def _dl_rows_toggled(self, rows: list[int]) -> None:
        if isinstance(self.runner, DownloadRunner):
            return
        self._dl_toggle([self.dl_proxy.mapToSource(self.dl_proxy.index(r, 0)).row() for r in rows])

    def _start_download(self, only: list[int] | None = None) -> None:
        if self.is_processing:
            return
        picks = sorted(i for i in (self.dl_checked if only is None else only) if i < len(self.dl_files))
        if not picks:
            self._info("Nothing selected", "Fetch a file list and tick at least one file first.")
            return
        dest_raw = self._clean(self.dl_dest.text())
        if not dest_raw:
            self._error("Error", "Choose a folder to save the downloads in.")
            return
        dest = Path(dest_raw)
        try:
            dest.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self._error("Error", f"Can't use that folder:\n\n{exc}")
            return
        threads = min(DL_MAX_PARALLEL, max(1, self.dl_threads.value()))
        is_torrent = [self.dl_files[i].url.startswith("torrent:") for i in picks]
        if any(is_torrent) and not all(is_torrent):
            self._error("Mixed selection", "Torrent files and web files can't be downloaded in the same run. "
                                           "Untick one kind and start again.")
            return
        jobs = [(i, self.dl_files[i]) for i in picks]
        if all(is_torrent):
            if torbox_key():  # TorBox's cache is tried first; the swarm only gets what isn't cached
                runner = TorBoxRunner(jobs, dest, threads, self.ui_q.put, self.pause_event, load_torrent_settings())
            else:
                if not self._torrent_ready(network=True):
                    return
                runner = TorrentRunner(jobs, dest, self.ui_q.put, self.pause_event, load_torrent_settings())
        else:
            if not self._dl_login_check([self.dl_files[i].url for i in picks]):
                return
            runner = DownloadRunner(jobs, dest, threads, self.dl_verify.isChecked(),
                                    self.dl_folders.isChecked(), self.ui_q.put, self.pause_event)
        self._t0, self._paused_total, self._pause_t, self._eta_tick = time.monotonic(), 0.0, None, 0.0
        self._dl_samples.clear()
        self.is_processing, self.is_paused = True, False
        self.pause_event.set()
        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.pause_btn.setText("Pause")
        self.dl_fetch_btn.setEnabled(False)
        self.lbl_phase.setText("Phase: Downloading")
        info = f"DOWNLOAD  |  {len(picks)} file(s)  ->  {dest}"
        self.lbl_run_info.setText(info if len(info) <= 80 else info[:38] + "..." + info[-39:])
        self.lbl_eta.setText("")
        self._set_bar(0, max(1, runner.bytes_total))
        self.lbl_total_prog.setText(f"Download Progress: 0 / {runner.files_total}")
        for i in picks:
            self.dl_model.set_status(i, "Queued")
        self.runner = runner
        self._set_settings_visible(False)  # the log gets the window while it runs
        threading.Thread(target=runner.run, daemon=True).start()

    def _dl_threads_changed(self, n: int) -> None:
        """The spinbox applies live: a running download picks up the new limit straight away."""
        self._dl_save_soon()
        if isinstance(self.runner, DownloadRunner):
            self.runner.set_threads(n)

    def _refresh_dl(self, force: bool = False) -> None:
        r = self.runner
        if not isinstance(r, DownloadRunner) or self._t0 is None:
            return
        now = time.monotonic()
        if not force and now - self._eta_tick < 0.5:
            return
        self._eta_tick = now
        done, total = r.bytes_done, r.bytes_total
        self._set_bar(min(done, total), max(1, total))
        self.lbl_total_prog.setText(f"Download Progress: {r.files_finished} / {r.files_total}")
        t, samples = self._active_secs(), self._dl_samples
        if not samples or t - samples[-1][0] >= 1.0:
            samples.append((t, done))
        while len(samples) > 2 and t - samples[0][0] > 20:  # speed = the last ~20 seconds
            samples.popleft()
        head = f"Elapsed: {fmt_duration(t)}  |  {fmt_size(done)} of {fmt_size(total)}"
        if self.is_paused:
            self.lbl_eta.setText(f"{head}  |  Paused")
            return
        t0, b0 = samples[0]
        speed = (done - b0) / (t - t0) if t > t0 else 0.0
        if speed <= 0:
            self.lbl_eta.setText(f"{head}  |  Starting...")
        else:
            left = f"  |  Est. remaining: ~{fmt_duration((total - done) / speed)}" if total > done else ""
            self.lbl_eta.setText(f"{head}  |  {fmt_size(int(speed))}/s{left}")

    def _show_dl_summary(self, sm: DownloadSummary) -> None:
        parts = [f"{sm.done} downloaded ({fmt_size(sm.bytes_received)})"]
        if sm.skipped:
            parts.append(f"{sm.skipped} already present")
        took = fmt_duration(sm.seconds)
        if not sm.failures:
            self._info("Downloads Complete", f"{', '.join(parts)} in {took}.")
            return
        lines = [f"  - {name}: {reason}" for _i, name, reason in sm.failures[:12]]
        if len(sm.failures) > 12:
            lines.append(f"  ...and {len(sm.failures) - 12} more (see the Status column)")
        text = (f"{', '.join(parts)}, {len(sm.failures)} failed, in {took}.\n\nFailed:\n" + "\n".join(lines)
                + "\n\nPartial downloads are kept, so a retry resumes where each one stopped.\n\n"
                  "Retry the failed files now?")
        retry, cancel = QMessageBox.StandardButton.Retry, QMessageBox.StandardButton.Cancel
        if QMessageBox.warning(self, "Downloads finished with errors", text, retry | cancel, retry) == retry:
            self._start_download(only=[i for i, _name, _why in sm.failures])

    def _dl_save_soon(self) -> None:
        self._dl_save_timer.start()  # restarts the 1.5 s countdown

    def _dl_save_session(self) -> None:
        """Write the file list, ticks, filter and options next to the app so a restart can pick up where this left off."""
        self._dl_save_timer.stop()
        if not self.dl_files:  # never replace a saved list with an empty one
            return
        try:
            data = {
                "version": 1,
                "urls": self.dl_url_text.toPlainText().strip(),
                "dest": self.dl_dest.text(),
                "threads": self.dl_threads.value(),
                "verify": self.dl_verify.isChecked(),
                "folders": self.dl_folders.isChecked(),
                "extras": self.dl_extras.isChecked(),
                "filter": self.dl_filter.text(),
                "was_running": isinstance(self.runner, DownloadRunner),
                "checked": sorted(self.dl_checked),
                "cols_user": True,
                "col_widths": {name: self.dl_table.columnWidth(col) for name, col in self.DL_COLS.items()},
                "files": [[f.name, f.url, f.size, f.group, f.md5, f.extra, f.preselect] for f in self.dl_files],
            }
            tmp = SESSION_FILE.with_name(SESSION_FILE.name + ".tmp")
            tmp.write_text(json.dumps(data), encoding="utf-8")
            os.replace(tmp, SESSION_FILE)
        except (OSError, ValueError, TypeError):
            pass  # remembering the session is a convenience; never let it interrupt a download

    def _dl_restore_session(self) -> None:
        try:
            data = json.loads(SESSION_FILE.read_text(encoding="utf-8"))
            files = [RemoteFile(str(n), str(u), None if sz is None else int(sz), str(g or ""), md5, bool(ex), bool(pre))
                     for n, u, sz, g, md5, ex, pre in data["files"]]
        except (OSError, ValueError, KeyError, TypeError):
            return
        if not files:
            return
        self.dl_url_text.setPlainText(str(data.get("urls", "")))
        self.dl_dest.setText(str(data.get("dest", "")))
        with contextlib.suppress(ValueError, TypeError):
            self.dl_threads.setValue(min(DL_MAX_PARALLEL, max(1, int(data.get("threads", 4)))))
        self.dl_verify.setChecked(bool(data.get("verify", True)))
        self.dl_folders.setChecked(bool(data.get("folders", False)))
        self.dl_extras.setChecked(bool(data.get("extras", False)))
        self.dl_filter.setText(str(data.get("filter", "")))
        if data.get("cols_user") and isinstance(data.get("col_widths"), dict):
            for name, width in data["col_widths"].items():
                if name in self.DL_COLS and isinstance(width, int):
                    self.dl_table.setColumnWidth(self.DL_COLS[name], max(50, min(2000, width)))
        self._dl_populate(files, [])
        self.dl_checked = {i for i in data.get("checked", []) if isinstance(i, int) and 0 <= i < len(files)}
        self._dl_apply_filter()
        self.dl_status.setText(f"Restored your last list: {len(files)} file(s), {len(self.dl_checked)} selected. "
                               "Press Start to continue - finished files are skipped and partial ones resume.")
        if data.get("was_running"):
            self._show_page("dl")
        dest, per_item = self._clean(self.dl_dest.text()), self.dl_folders.isChecked()
        if dest and (picks := sorted(self.dl_checked)):
            threading.Thread(target=self._dl_scan_disk, args=(files, picks, Path(dest), per_item), daemon=True).start()

    def _dl_scan_disk(self, files: list[RemoteFile], picks: list[int], dest: Path, per_item: bool) -> None:
        """Worker thread: mark restored rows that are already finished or partly downloaded."""
        probe = DownloadRunner([], dest, 1, False, per_item, lambda _e: None, threading.Event())
        for i in picks:
            rf = files[i]
            if rf.url.startswith("torrent:"):
                continue  # libtorrent checks what is already on disk itself when the download starts
            try:
                path = probe._target(rf)
                if path.exists() and (rf.size is None or path.stat().st_size == rf.size):
                    self.ui_q.put(("dl_row", i, "Already downloaded"))
                else:
                    part = path.with_name(path.name + ".part")
                    if part.exists():
                        self.ui_q.put(("dl_row", i, f"Partial: {fmt_size(part.stat().st_size)} (will resume)"))
            except (OSError, ValueError):
                continue
